=======
Credits
=======

* Anders Hovmöller <anders.hovmoller@trioptima.com>
* Felipe Pontes <felipemfpontes@gmail.com>
* William Orr <will@worrbase.com>
* Trevin Gandhi <trevin.gandhi@petuum.com>
* Daniel Hahler <git@thequod.de>
* Marcelo Da Cruz Pinto
* Jakub Stolarski
* Hristo Georgiev
* Savo Kovačević <savo.s.kovacevic@gmail.com>
* Nathan Klapstein <nklapste@ualberta.ca>
* Brian Skinn <brian.skinn@gmail.com>
* Jim Jazwiecki <jim.jazwiecki@gmail.com>
* neroks <gneroks@gmail.com>
* John Vandenberg <jayvdb@gmail.com>
* Luca Simonetto <luca.simonetto.94@gmail.com>
* Emil Stenström <emil@emilstenstrom.se>
* Roxane Bellott <roxane.bellot@gmail.com>
* Tomáš Chvátal <tchvatal@suse.com>
* Felix Divo <https://github.com/felixdivo>
* Andreas Finkler <andi.finkler@gmail.com>
* sed-i
* Peter Hill <peter.hill@york.ac.uk>
* Samuel Razzell <srazzell@apple.com>
* Daniel Versoza Alves <daniel.alves@voxy.com>
* Zac Hatfield-Dodds <zac.hatfield.dodds@gmail.com>
* Jan Królikowski <yanekk86@gmail.com>
* Tal Amuyal <talamuyal@gmail.com>
* Eivind Jahren <eivind.jahren@gmail.com>
* WiredNerd <pbuschmail-gitlab@yahoo.com>
* Kees Hink <kees@fourdigits.nl>
* Jim Rybarski <jim@rybarski.com>
* Christopher J. Brody <chris.brody+brodybits@gmail.com>
* Century-ss <hgfc7543ggfdch@gmail.com>
* Michael Champagne <michael.champagne@elapsetech.com>
